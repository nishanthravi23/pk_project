import { Ot } from "../models";
import { IRepository } from "./service";

export class OtService extends IRepository<Ot> {}
