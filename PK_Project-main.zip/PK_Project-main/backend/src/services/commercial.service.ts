import { Commercial } from "../models";
import { IRepository } from "./service";

export class CommercialService extends IRepository<Commercial> {}
