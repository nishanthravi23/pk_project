import { Item } from "../models";
import { IRepository } from "./service";

export class ItemService extends IRepository<Item> {}
