import { Customer } from "./../models/customer";
import { IRepository } from "./service";

export class CustomerService extends IRepository<Customer> {}
