import { Inventory } from "../models";
import { IRepository } from "./service";

export class InventoryService extends IRepository<Inventory> {}
