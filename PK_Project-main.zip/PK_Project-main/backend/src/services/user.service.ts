import { User } from "../models";
import { IRepository } from "./service";

export class UserService extends IRepository<User> {}
