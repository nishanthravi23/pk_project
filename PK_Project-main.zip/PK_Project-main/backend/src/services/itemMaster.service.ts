import { ItemMaster } from "../models";
import { IRepository } from "./service";

export class ItemMasterService extends IRepository<ItemMaster> {}
