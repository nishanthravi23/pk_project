import { Vendor } from "../models";
import { IRepository } from "./service";

export class VendorService extends IRepository<Vendor> {}
