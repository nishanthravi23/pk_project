import { TransportBill } from "../models";
import { IRepository } from "./service";

export class TransportBillService extends IRepository<TransportBill> {}
