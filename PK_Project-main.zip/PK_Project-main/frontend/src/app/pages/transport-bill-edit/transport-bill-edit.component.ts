import { Component } from '@angular/core';

@Component({
  selector: 'app-transport-bill-edit',
  templateUrl: './transport-bill-edit.component.html',
  styleUrls: ['./transport-bill-edit.component.scss']
})
export class TransportBillEditComponent {

}
