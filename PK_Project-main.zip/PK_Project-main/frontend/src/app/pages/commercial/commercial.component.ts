import { Component } from "@angular/core";
import { CommercialFormComponent } from "src/app/components/commercial-form/commercial-form.component";

@Component({
  selector: "app-commercial",
  templateUrl: "./commercial.component.html",
  styleUrls: ["./commercial.component.scss"],
})
export class CommercialComponent {}
