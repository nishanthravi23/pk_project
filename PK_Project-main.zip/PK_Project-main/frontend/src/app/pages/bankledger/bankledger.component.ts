import { Component } from '@angular/core';

@Component({
  selector: 'app-bankledger',
  templateUrl: './bankledger.component.html',
  styleUrls: ['./bankledger.component.scss']
})
export class BankledgerComponent {

}
