import { Component } from '@angular/core';

@Component({
  selector: 'app-managebank',
  templateUrl: './managebank.component.html',
  styleUrls: ['./managebank.component.scss']
})
export class ManagebankComponent {

}
