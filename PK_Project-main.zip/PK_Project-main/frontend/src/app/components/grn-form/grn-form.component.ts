import { Component } from '@angular/core';

@Component({
  selector: 'app-grn-form',
  templateUrl: './grn-form.component.html',
  styleUrls: ['./grn-form.component.scss']
})
export class GrnFormComponent {

}
