export interface Department {
  id: number;
  name: string;
  monthlySalary: number;
  otSalary: number;
  sundaySalary: number;
  leaveDetection: number;
}
