export interface Ot {
  id: number;
  date: Date;
  employeeId: number;
  employeeName?: number;
  hours: number;
  isOt: boolean;
  isSunday: boolean;
}
