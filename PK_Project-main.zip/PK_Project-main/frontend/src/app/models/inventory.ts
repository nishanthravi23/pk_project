export interface Inventory {
  id: number;
  material: string;
  stock: number;
  usage: number;
  unit: string;
}
