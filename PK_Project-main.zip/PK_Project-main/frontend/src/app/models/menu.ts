export interface Menu {
  title: string;
  icon: string;
  path?: string;
  children?: Menu[];
}
