export interface Mentor {
  id: number;
  employeesCount?: number;
  studentId: number[];
  name: string;
  email: string;
  password: string;
}
